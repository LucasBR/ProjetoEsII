/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Conexao;

/**
 *
 * @author Zurawski
 */
public class DocinhoDAO {
    
}
